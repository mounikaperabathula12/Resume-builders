
import React, { useRef } from 'react';
import { Upload, FileText, X } from 'lucide-react';
import { extractTextFromPdf } from '../services/pdfService';

interface FileUploadProps {
  label: string;
  onTextExtracted: (text: string, fileName: string) => void;
  onClear: () => void;
  fileName?: string;
}

const FileUpload: React.FC<FileUploadProps> = ({ label, onTextExtracted, onClear, fileName }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      try {
        const text = await extractTextFromPdf(file);
        onTextExtracted(text, file.name);
      } catch (err) {
        alert("Error reading PDF file. Please ensure it's a valid PDF.");
      }
    } else if (file) {
      alert("Please upload a PDF file.");
    }
  };

  return (
    <div className="w-full">
      <label className="block text-sm font-semibold text-gray-700 mb-2">{label}</label>
      {!fileName ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-blue-500 hover:bg-blue-50 transition-all cursor-pointer group"
        >
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept=".pdf" 
            onChange={handleFileChange} 
          />
          <Upload className="mx-auto h-12 w-12 text-gray-400 group-hover:text-blue-500 mb-4" />
          <p className="text-gray-600 font-medium">Click to upload PDF</p>
          <p className="text-xs text-gray-400 mt-2">Maximum file size: 5MB</p>
        </div>
      ) : (
        <div className="flex items-center justify-between p-4 bg-blue-50 border border-blue-200 rounded-xl">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-800 truncate max-w-[200px]">{fileName}</p>
              <p className="text-xs text-blue-500">PDF Document</p>
            </div>
          </div>
          <button 
            onClick={onClear}
            className="p-1 hover:bg-blue-100 rounded-full text-gray-400 hover:text-red-500 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
