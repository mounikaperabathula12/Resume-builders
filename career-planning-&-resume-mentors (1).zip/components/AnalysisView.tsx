
import React from 'react';
import { AnalysisResult } from '../types';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, 
  BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid 
} from 'recharts';
import { CheckCircle2, AlertCircle, Lightbulb, Search, Star, ArrowLeft } from 'lucide-react';

interface AnalysisViewProps {
  result: AnalysisResult;
  onReset: () => void;
}

const AnalysisView: React.FC<AnalysisViewProps> = ({ result, onReset }) => {
  const COLORS = ['#3b82f6', '#e2e8f0'];
  
  const pieData = [
    { name: 'Match', value: result.matchPercentage },
    { name: 'Gap', value: 100 - result.matchPercentage }
  ];

  const barData = [
    { name: 'Skills Match', score: result.matchPercentage },
    { name: 'ATS Score', score: result.atsScore },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <button 
        onClick={onReset}
        className="mb-8 flex items-center text-blue-600 font-semibold hover:underline"
      >
        <ArrowLeft className="h-5 w-5 mr-2" />
        Back to Analysis
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Main Stats */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Overall Match</h3>
          <div className="h-48 w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  startAngle={180}
                  endAngle={0}
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex items-center justify-center pt-8">
              <span className="text-4xl font-black text-blue-600">{result.matchPercentage}%</span>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-2 text-center">{result.summary}</p>
        </div>

        {/* ATS Score */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center">
          <div className="flex items-center space-x-2 mb-4">
            <Star className="h-6 w-6 text-yellow-500 fill-yellow-500" />
            <h3 className="text-lg font-bold text-gray-800">ATS Score</h3>
          </div>
          <div className="text-6xl font-black text-gray-800 mb-4">{result.atsScore}</div>
          <div className="w-full bg-gray-100 rounded-full h-3 mb-4">
            <div 
              className="bg-yellow-500 h-3 rounded-full transition-all duration-1000" 
              style={{ width: `${result.atsScore}%` }}
            />
          </div>
          <p className="text-xs text-gray-400 uppercase tracking-widest font-bold">Optimization Rank</p>
        </div>

        {/* Scoring Breakdown */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Match Breakdown</h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12 }} />
                <Tooltip cursor={{ fill: '#f8fafc' }} />
                <Bar dataKey="score" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Skills Matched */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-6">
            <div className="p-2 bg-green-100 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">Skills Matched</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {result.skillsMatched.map((skill, i) => (
              <span key={i} className="px-3 py-1 bg-green-50 text-green-700 text-sm font-medium rounded-full border border-green-100">
                {skill}
              </span>
            ))}
            {result.skillsMatched.length === 0 && <p className="text-gray-400 italic">No direct skill matches identified.</p>}
          </div>
        </div>

        {/* Missing Skills */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-6">
            <div className="p-2 bg-red-100 rounded-lg">
              <AlertCircle className="h-5 w-5 text-red-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">Missing Skills</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {result.missingSkills.map((skill, i) => (
              <span key={i} className="px-3 py-1 bg-red-50 text-red-700 text-sm font-medium rounded-full border border-red-100">
                {skill}
              </span>
            ))}
            {result.missingSkills.length === 0 && <p className="text-gray-400 italic">You have all the required skills mentioned!</p>}
          </div>
        </div>

        {/* Improvements */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-6">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Lightbulb className="h-5 w-5 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">Resume Improvements</h3>
          </div>
          <ul className="space-y-4">
            {result.improvements.map((imp, i) => (
              <li key={i} className="flex items-start">
                <div className="h-6 w-6 rounded-full bg-blue-50 text-blue-600 text-xs flex items-center justify-center font-bold mr-3 mt-0.5 shrink-0">
                  {i + 1}
                </div>
                <p className="text-gray-600 text-sm leading-relaxed">{imp}</p>
              </li>
            ))}
          </ul>
        </div>

        {/* Keyword Tips */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center space-x-2 mb-6">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Search className="h-5 w-5 text-indigo-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800">Keyword Optimization</h3>
          </div>
          <div className="space-y-4">
            {result.keywordTips.map((tip, i) => (
              <div key={i} className="p-3 bg-gray-50 rounded-xl text-gray-700 text-sm border border-gray-100">
                {tip}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisView;
