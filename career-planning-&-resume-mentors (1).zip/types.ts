
export interface AnalysisResult {
  matchPercentage: number;
  atsScore: number;
  skillsMatched: string[];
  missingSkills: string[];
  improvements: string[];
  keywordTips: string[];
  summary: string;
}

export interface FileData {
  name: string;
  text: string;
}
