
import React, { useState, useCallback } from 'react';
import { 
  Briefcase, 
  FileCheck, 
  Sparkles, 
  Loader2, 
  ChevronRight, 
  ShieldCheck, 
  Zap, 
  Layout 
} from 'lucide-react';
import FileUpload from './components/FileUpload';
import AnalysisView from './components/AnalysisView';
import { analyzeResume } from './services/geminiService';
import { AnalysisResult } from './types';

const App: React.FC = () => {
  const [resumeText, setResumeText] = useState('');
  const [resumeName, setResumeName] = useState('');
  const [jdText, setJdText] = useState('');
  const [jdName, setJdName] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleAnalyze = async () => {
    if (!resumeText || !jdText) {
      alert("Please upload both a resume and a job description (or paste text).");
      return;
    }

    setIsAnalyzing(true);
    try {
      const analysisResult = await analyzeResume(resumeText, jdText);
      setResult(analysisResult);
    } catch (error: any) {
      alert(error.message || "An error occurred during analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setResult(null);
  };

  if (result) {
    return (
      <div className="min-h-screen bg-[#f8fafc]">
        <nav className="bg-white border-b border-gray-100 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Briefcase className="text-white h-5 w-5" />
              </div>
              <span className="font-bold text-gray-900 tracking-tight">Career Planning & Resume Mentors</span>
            </div>
          </div>
        </nav>
        <AnalysisView result={result} onReset={handleReset} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-blue-100">
      {/* Navbar */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
                <Briefcase className="text-white h-5 w-5" />
              </div>
              <span className="font-extrabold text-slate-900 text-xl tracking-tight">CPRM</span>
            </div>
            <div className="hidden md:flex items-center space-x-8 text-sm font-medium text-slate-600">
              <a href="#" className="hover:text-blue-600 transition-colors">How it works</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Testimonials</a>
              <a href="#" className="bg-slate-900 text-white px-5 py-2.5 rounded-full hover:bg-slate-800 transition-all">Get Mentorship</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative overflow-hidden pt-20 pb-16 lg:pt-32 lg:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-700 text-xs font-bold mb-6 animate-bounce">
            <Sparkles className="h-3.5 w-3.5" />
            <span>AI-POWERED ANALYSIS</span>
          </div>
          <h1 className="text-5xl lg:text-7xl font-black text-slate-900 mb-8 tracking-tight">
            Smart Resume Analysis <br className="hidden lg:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              for Your Dream Job
            </span>
          </h1>
          <p className="text-lg lg:text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed font-medium">
            Upload your resume and the job description to get instant insights, 
            ATS optimization tips, and skill gap analysis to land your next interview.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#analyzer" className="w-full sm:w-auto px-8 py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 hover:shadow-2xl hover:shadow-blue-200 transition-all flex items-center justify-center">
              Analyze Now
              <ChevronRight className="ml-2 h-5 w-5" />
            </a>
            <div className="flex items-center space-x-4 text-slate-500 text-sm font-semibold">
              <div className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-1.5 text-green-500" />
                <span>100% Privacy</span>
              </div>
              <div className="flex items-center">
                <Zap className="h-4 w-4 mr-1.5 text-yellow-500" />
                <span>Real-time results</span>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative background elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none">
          <div className="absolute top-1/4 -left-1/4 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-50"></div>
          <div className="absolute bottom-1/4 -right-1/4 w-96 h-96 bg-indigo-100 rounded-full blur-3xl opacity-50"></div>
        </div>
      </header>

      {/* Main Feature Section */}
      <main id="analyzer" className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
          
          {/* Resume Upload */}
          <div className="bg-white p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 transition-all hover:shadow-2xl">
            <div className="flex items-center space-x-3 mb-8">
              <div className="p-3 bg-blue-50 rounded-2xl">
                <FileCheck className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900">Resume</h2>
                <p className="text-sm text-slate-500">Upload your latest CV in PDF</p>
              </div>
            </div>
            
            <FileUpload 
              label="Select Resume PDF"
              fileName={resumeName}
              onTextExtracted={(text, name) => {
                setResumeText(text);
                setResumeName(name);
              }}
              onClear={() => {
                setResumeText('');
                setResumeName('');
              }}
            />
            
            {resumeText && (
              <div className="mt-6 animate-in fade-in slide-in-from-top-2">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Extracted Content Preview</p>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 h-32 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                  {resumeText}
                </div>
              </div>
            )}
          </div>

          {/* Job Description Section */}
          <div className="bg-white p-8 rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 transition-all hover:shadow-2xl">
            <div className="flex items-center space-x-3 mb-8">
              <div className="p-3 bg-indigo-50 rounded-2xl">
                <Layout className="h-6 w-6 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900">Job Description</h2>
                <p className="text-sm text-slate-500">Paste text or upload PDF</p>
              </div>
            </div>

            <div className="space-y-6">
              <FileUpload 
                label="Upload Job Ad PDF"
                fileName={jdName}
                onTextExtracted={(text, name) => {
                  setJdText(text);
                  setJdName(name);
                }}
                onClear={() => {
                  setJdText('');
                  setJdName('');
                }}
              />
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center" aria-hidden="true">
                  <div className="w-full border-t border-slate-200"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-3 font-bold text-slate-400 tracking-widest">Or Paste Text</span>
                </div>
              </div>

              <textarea 
                className="w-full h-48 p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all outline-none resize-none placeholder:text-slate-400"
                placeholder="Paste the full job description here..."
                value={jdText}
                onChange={(e) => setJdText(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-16 text-center">
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing || !resumeText || !jdText}
            className={`
              group relative inline-flex items-center px-12 py-5 rounded-full text-lg font-black transition-all overflow-hidden
              ${isAnalyzing || !resumeText || !jdText 
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                : 'bg-slate-900 text-white hover:bg-black hover:scale-105 active:scale-95 shadow-2xl shadow-slate-300'
              }
            `}
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="animate-spin h-6 w-6 mr-3" />
                Analyzing Your Future...
              </>
            ) : (
              <>
                Analyze Match
                <Sparkles className="ml-3 h-5 w-5 transition-transform group-hover:rotate-12" />
              </>
            )}
          </button>
          <p className="mt-4 text-sm text-slate-500 font-medium">
            {!resumeText || !jdText ? "Upload both documents to start analysis" : "Estimated time: 10-15 seconds"}
          </p>
        </div>
      </main>

      {/* Trust Section */}
      <section className="bg-white py-16 mt-12 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-slate-400 text-xs font-bold uppercase tracking-[0.3em] mb-12">Trusted by job seekers at</p>
          <div className="flex flex-wrap justify-center items-center gap-12 grayscale opacity-40">
            {['Google', 'Meta', 'Amazon', 'Apple', 'Netflix', 'Microsoft'].map((brand) => (
              <span key={brand} className="text-3xl font-black tracking-tighter text-slate-900 italic">{brand}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center space-x-3 text-white">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Briefcase className="h-4 w-4" />
            </div>
            <span className="font-bold tracking-tight">CPRM</span>
          </div>
          <p className="text-sm">© 2024 Career Planning & Resume Mentors. All rights reserved.</p>
          <div className="flex space-x-6 text-sm font-medium">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
