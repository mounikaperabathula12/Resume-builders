
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

export const analyzeResume = async (resumeText: string, jobDescription: string): Promise<AnalysisResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");

  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = `
    Analyze the following resume against the provided job description. 
    Provide a detailed match analysis including scores and specific feedback.
    
    Resume Text:
    ${resumeText}
    
    Job Description:
    ${jobDescription}
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          matchPercentage: {
            type: Type.NUMBER,
            description: "A percentage from 0 to 100 representing how well the resume matches the JD.",
          },
          atsScore: {
            type: Type.NUMBER,
            description: "A score from 0 to 100 representing how well the resume is optimized for ATS systems.",
          },
          skillsMatched: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "List of skills found in both the resume and the JD.",
          },
          missingSkills: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "List of key skills found in the JD but missing from the resume.",
          },
          improvements: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Actionable suggestions to improve the resume content and structure.",
          },
          keywordTips: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Keywords to add to help bypass ATS filters.",
          },
          summary: {
            type: Type.STRING,
            description: "A brief professional summary of the match.",
          },
        },
        required: ["matchPercentage", "atsScore", "skillsMatched", "missingSkills", "improvements", "keywordTips", "summary"],
      },
    },
  });

  try {
    const result = JSON.parse(response.text || "{}");
    return result as AnalysisResult;
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    throw new Error("Failed to analyze resume. Please try again.");
  }
};
